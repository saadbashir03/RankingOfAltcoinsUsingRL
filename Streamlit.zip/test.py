import streamlit as st
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
st.write("""
# Prediction of Altcoins using Machine Learning App
This app predicts the **Altcoins price**!  by using weighted average of different factors.
""")
st.write('---')
#  Loads the Boston House Price Dataset
df=pd.read_csv('btcdata.csv')

#display the dataframe
st.write(df.tail(6))




#split the dataframe into features and target
C=df[['Weighted_Average']]
D=df[['pred_close']]

from sklearn.model_selection import train_test_split

c_train, c_test, d_train, d_test = train_test_split(C, D, test_size=0.2, random_state=13)

# Fitting Random Forest Regression to the dataset
# import the regressor
from sklearn.ensemble import RandomForestRegressor
 
 # create regressor object
RandomForestRegressor = RandomForestRegressor(n_estimators = 100, random_state = 56)
 
# fit the regressor with x and y data
RandomForestRegressor.fit(c_train,d_train)
RandomForestRegressor.score(c_train,d_train)
st.write(RandomForestRegressor.score(c_test,d_test))


# Predicting a new result
y_pred = RandomForestRegressor.predict(c_test)  
# st.write(y_pred)

#Enter the Price of Bitcoin
st.write("""
## Enter the Price of Bitcoin
""")
bitcoin_price = st.number_input("Price of Bitcoin",df['Close'].tail(1).values[0])


# Enter value of Fear and Greed index
st.write("""
## Enter value of Fear and Greed index
""")
# fear_greed_index = st.number_input("Index", 1, 100, int(df['fng_value'].mean()))
fear_greed_index = st.number_input("Index", 1, 100,df['fng_value'].tail(1).values[0])


#Enter value of Relative Strength index 
st.write("""
## Enter value of Relative Strength index
""")
relative_strength_index = st.number_input("RSI",1,100,int(df['Rsi'].tail(1)))


#Enter value of SMA
st.write("""
## Enter value of Simple Moving Average
""")
# vsma= st.number_input("sma",int(df['sma_20'].mean()))
sma= st.number_input("sma",value=df['sma_20'].tail(1).values[0])

#Enter value of lower Bollinger Band
st.write("""
## Enter value of Lower Bollinger Band
""")
lower_bb= st.number_input("lower_bb",value=df['lower_bb'].tail(1).values[0])

#Enter value of SMA
st.write("""
## Enter value of upper Bollinger Band
""")
upper_bb= st.number_input("upper_bb",value=df['upper_bb'].tail(1).values[0])






#calculating Weighted Average
weighted=(bitcoin_price*10+fear_greed_index*2+relative_strength_index*2+sma*4+lower_bb*4+upper_bb*4)/26
st.write(weighted)

st.write("Predicted Price of Altcoin is:")
st.write(RandomForestRegressor.predict([[weighted]]))

# st.write(RandomForestRegressor.predict([[10169.624546]]))
